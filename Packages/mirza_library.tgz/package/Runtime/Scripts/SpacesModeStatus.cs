namespace com.nttqonoq.devices.android.mirzalibrary
{
    /// <summary>
    /// Spacesモード状態 Enum
    /// </summary>
    public enum SpacesModeStatus
    {
        Off = 0, // SpacesモードOFF（グラスUI）
        On = 1 // SpacesモードON
    }
}