namespace com.nttqonoq.devices.android.mirzalibrary
{
    /// <summary>
    /// 充電状態 Enum
    /// </summary>
    public enum ChargeStatus
    {
        Off = 0, // 充電OFF
        On = 1 // 充電ON
    }
}