namespace com.nttqonoq.devices.android.mirzalibrary
{
    /// <summary>
    /// サービスの状態 Enum
    /// </summary>
    public enum ServiceState
    {
        Connecting = 0, // 接続中
        Connected = 1, // 接続済み
        Disconnecting = 2, // 切断中
        Disconnected = 3, // 切断済み
        ConnectionError = 4, // 接続エラー
        VersionInconsistent = 5 // バージョン不整合
    }
}