namespace com.nttqonoq.devices.android.mirzalibrary
{
    /// <summary>
    /// 画面表示状態 Enum
    /// </summary>
    public enum DisplayStatus
    {
        Off = 0, // 画面OFF
        On = 1 // 画面ON
    }
}