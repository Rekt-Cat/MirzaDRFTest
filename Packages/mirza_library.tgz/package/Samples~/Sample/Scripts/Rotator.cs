using UnityEngine;

namespace com.nttqonoq.devices.android.mirzalibrary.samples
{
    public class Rotator : MonoBehaviour
    {
        private void Update()
        {
            gameObject.transform.Rotate(new Vector3(20, 25, 15) * Time.deltaTime);
        }
    }
}