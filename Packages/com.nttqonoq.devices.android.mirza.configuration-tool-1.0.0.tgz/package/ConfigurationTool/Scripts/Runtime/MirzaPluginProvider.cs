﻿#if USING_MIRZA_SDK

using com.nttqonoq.devices.android.mirzalibrary;

namespace NTTQONOQ.Android.MiRZA.SDK.ConfigurationTool.Runtime
{
    public static class MirzaPluginProvider
    {
        private static IMirzaPlugin _mirzaPlugin;

        public static IMirzaPlugin MirzaPlugin
        {
            get
            {
                if (_mirzaPlugin != null)
                {
                    return _mirzaPlugin;
                }
#if UNITY_EDITOR
                _mirzaPlugin = new MirzaPluginSimulator();
#else
                _mirzaPlugin = new MirzaPlugin();
#endif
                return _mirzaPlugin;
            }
        }
    }
}

#endif