using System;

namespace NTTQONOQ.Android.MiRZA.SDK.ConfigurationTool.Editor
{
    /// <summary>
    /// Templates Validation Parameters
    /// </summary>
    [Serializable]
    public class TemplatesParams
    {
        #region Spaces

        public Param HandTrackingFeatureEnabled;

        #endregion
    }
}