﻿namespace NTTQONOQ.Android.MiRZA.SDK.ConfigurationTool.Editor
{
    public static class Constants
    {
        /// <summary>
        /// TouchpadRayQONOQFusionInteraction
        /// </summary>
        public static readonly string ControllerPrefabGuid = "f005d2f16e547cf46b0743986ad694e3";

        public static readonly string RenderCameraPrefabGuid = "f667af279b458184986cff64c7d400a2";

        public static readonly string ControllerGameObjectName = "TouchpadRayQONOQFusionInteraction";

        public static readonly string RenderCameraGameObjectName = "RenderCamera";

        public static readonly string DrfControllerRelativePositionPath = "/TouchpadRayQONOQFusionInteraction/Canvas Controller/Controller Position Head Mirror/Controller Relative Position";

        public static readonly string DrfControllerPointerPath = "/TouchpadRayQONOQFusionInteraction/Canvas Controller/Controller Position Head Mirror/Controller Relative Position/Pointer";

        public static readonly string DrfNotifyConnectionPath = "/TouchpadRayQONOQFusionInteraction/TouchpadRayCanvasControllerCompanion/Canvas/NotificationArea/Notify-Connection";

        public static readonly string DrfCanvasControllerCompanionPath = "/TouchpadRayQONOQFusionInteraction/TouchpadRayCanvasControllerCompanion";

        public static readonly string DrfRenderCameraPath = "/AR Setup/XR Origin (XR Rig)/Camera Offset/Main Camera/RenderCamera";

        public static readonly string SpacesBasePath = "Assets/Samples/Snapdragon Spaces/";

        public static readonly string SpacesXRSimulatorSearchPattern = "Core Samples/Shared Assets/Prefabs/Spaces XR Simulator.prefab";

        public static readonly string PointerSimulatorPrefabPath = "Packages/com.nttqonoq.devices.android.mirza.configuration-tool/ConfigurationTool/Prefabs/PointerSimulator.prefab";

        public static readonly string QCHTBasePath = "Assets/Samples/QCHT Unity Interactions/";

        public static readonly string DefaultQCHTInputActionsName = "Default QCHT Input Actions";

        public static readonly string DefaultQCHTInputActionsSearchPattern = "Core Assets/InputActions/Default QCHT Input Actions.inputactions";

        public static readonly string QCHTXROriginGameObjectName = "QCHT XR Origin";

        public static readonly string QCHTXROriginPrefabSearchPattern = "Core Assets/Prefabs/QCHT XR Origin.prefab";

        public static readonly string GuidePageUrl = "https://www.devices.nttqonoq.com/developer/doc/";

        public static readonly string DefaultLeftControllerGameObjectPath = "/XR Origin (XR Rig)/Camera Offset/Left Controller";

        public static readonly string DefaultRightControllerGameObjectPath = "/XR Origin (XR Rig)/Camera Offset/Right Controller";

        public static readonly string MirzaConfigurationToolSamplesBasePath = "Assets/Samples/MiRZA Configuration Tool/";

        public static readonly string QONOQControllerFolderSearchPattern = "Dual Render Fusion Controller/QONOQController";

        public static readonly string TargetEyeIsNoneInUrpProject = "None(URP)";

        public static readonly string MRModeAutoSwitcherGameObjectName = "MR Mode Auto Switcher";

        public static readonly string ImageAnalyzeSpeakerGameObjectName = "Image Analyze Speaker";
    }
}