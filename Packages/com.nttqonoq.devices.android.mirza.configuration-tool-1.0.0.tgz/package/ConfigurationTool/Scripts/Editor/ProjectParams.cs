using System;
using System.Collections.Generic;
using UnityEngine.Serialization;

namespace NTTQONOQ.Android.MiRZA.SDK.ConfigurationTool.Editor
{
    /// <summary>
    /// Project Validation Parameters
    /// </summary>
    [Serializable]
    public class ProjectParams
    {
        public List<PackageParam> Packages;

        public List<AssetParam> Assets;

        #region Spaces

        public Param SnapdragonSpacesFeatureGroupEnabled;

        public Param BaseRuntimeFeatureEnabled;

        public Param LaunchAppOnViewer;

        public Param LaunchControllerOnHost;

        public Param ExportHeadless;

        public Param DualRenderFusionFeatureEnabled;

        public Param SnapdragonSpacesExperimentalFeatureGroupEnabled;

        public Param IgnoreOpenXRVersion;

        #endregion

        // #region MiRZA
        // #endregion

        #region OpenXR

        public Param InitializeXROnStartup;

        public Param OpenXRPluginEnabled;

        #endregion

        #region Other

        public Param UnityVersion;

        public Param Platform;

        public Param AndroidMinimumApiLevel;

        public Param AndroidTargetApiLevel;

        public Param ActiveInputHandling;

        public Param AllowUnsafeCode;

        #endregion
    }
}