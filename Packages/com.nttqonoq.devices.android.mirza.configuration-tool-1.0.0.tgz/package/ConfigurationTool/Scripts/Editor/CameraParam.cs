﻿using System;
using UnityEngine;

namespace NTTQONOQ.Android.MiRZA.SDK.ConfigurationTool.Editor
{
    [Serializable]
    public class CameraParam
    {
        public string Name;

        public string ScenePath;

        public string Tag;

        public string Layer;

        public Param TargetDisplay;

        public string TargetEye;

        public bool IsActive;

        public bool IsActiveSelf;

        public bool IsUrpPhoneCamera;

        public bool IsXrOriginCamera;

        public Camera TargetCamera { get; set; }
    }
}