using System;

namespace NTTQONOQ.Android.MiRZA.SDK.ConfigurationTool.Editor
{
    /// <summary>
    /// Validation Parameter
    /// </summary>
    [Serializable]
    public class Param
    {
        public bool Exists;

        public string Expected;

        public string Actual;

        public string Message;

        public Param()
        {
        }

        public static Param CreateNotExists()
        {
            return new Param
            {
                Exists = false,
            };
        }
    }
}