using System;

namespace NTTQONOQ.Android.MiRZA.SDK.ConfigurationTool.Editor
{
    [Serializable]
    public class PackageParam
    {
        public string Name;

        public string DisplayName;

        public string MinRequiredVersion;

        public string ActualVersion;

        public string ExpectedVersion;

        public bool Exists;
    }
}