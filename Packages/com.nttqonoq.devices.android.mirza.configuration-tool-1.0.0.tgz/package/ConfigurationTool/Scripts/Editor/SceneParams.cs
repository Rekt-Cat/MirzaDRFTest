﻿using System;
using System.Collections.Generic;
using UnityEngine.Serialization;

namespace NTTQONOQ.Android.MiRZA.SDK.ConfigurationTool.Editor
{
    /// <summary>
    /// Scene Validation Parameters
    /// </summary>
    [Serializable]
    public class SceneParams
    {
        #region Spaces

        public Param DynamicOpenXRLoader;

        public Param SpacesHostView;

        public Param SpacesXRSimulator;

        public Param HandTrackingFeatureEnabled;

        public Param SpacesPermissionHelper;

        public Param SpacesLifecycleEvents;

        #endregion

        #region MiRZA

        public Param DualRenderFusionController;

        public Param RenderCamera;

        #endregion

        #region QCHT

        public Param QCHTXROrigin;

        #endregion

        #region Other

        public List<CameraParam> Cameras;

        public Param ARSession;

        public Param XROrigin;

        public Param ARCameraManager;

        public Param ARCameraBackground;

        public Param XRInteractionManager;

        public Param ConfiguredInputActionManager;

        public Param MRModeAutoSwitcher;

        #endregion
    }
}