namespace NTTQONOQ.Android.MiRZA.SDK.ConfigurationTool.Editor
{
    public class MenuItemData
    {
        public string ID { get; }

        public string DisplayName { get; }

        public MenuItemData(string id, string displayName)
        {
            ID = id;
            DisplayName = displayName;
        }

        public override string ToString()
        {
            return DisplayName;
        }
    }
}