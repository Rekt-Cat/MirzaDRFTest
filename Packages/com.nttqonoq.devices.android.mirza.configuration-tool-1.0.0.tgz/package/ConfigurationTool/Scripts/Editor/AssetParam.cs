using System;

namespace NTTQONOQ.Android.MiRZA.SDK.ConfigurationTool.Editor
{
    [Serializable]
    public class AssetParam
    {
        public string Name;

        public string PackageName;

        public string PackageDisplayName;

        public bool Exists;
    }
}