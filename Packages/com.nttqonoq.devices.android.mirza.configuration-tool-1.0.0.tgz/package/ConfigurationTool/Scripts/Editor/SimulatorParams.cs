﻿using System;
using UnityEngine.Serialization;

namespace NTTQONOQ.Android.MiRZA.SDK.ConfigurationTool.Editor
{
    /// <summary>
    /// Simulator Validation Parameters
    /// </summary>
    [Serializable]
    public class SimulatorParams
    {
        public Param InitializeXROnStartupPC;

        public Param InitializeXROnStartupAndroid;

        public Param SpacesXRSimulator;

        public Param StartConnected;

        public Param OpenXRPluginEnabled;

        public Param XRSimulationPluguinEnabled;

        public Param BaseRuntimeFeatureEnabled;

        public Param PointerSimulator;

        public Param PointerGameObject;

        public Param XRDeviceSimulatorEnabled;

        public Param HandTrackingSimulationEnabled;

        public Param MirzaDeviceEventSimulator;
    }
}