using System;

namespace NTTQONOQ.Android.MiRZA.SDK.ConfigurationTool.Editor
{
    [Serializable]
    public class DebugParams
    {
        public Param FrameTimingStatsEnabled;

        public Param DebugPrefabAdded;
    }
}