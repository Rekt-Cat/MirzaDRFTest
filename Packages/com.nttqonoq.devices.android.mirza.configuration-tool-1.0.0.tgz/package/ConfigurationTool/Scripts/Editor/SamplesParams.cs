using System;

namespace NTTQONOQ.Android.MiRZA.SDK.ConfigurationTool.Editor
{
    /// <summary>
    /// Samples Validation Parameters
    /// </summary>
    [Serializable]
    public class SamplesParams
    {
        #region Spaces

        public Param CameraAccessFeatureEnabled;

        #endregion

        #region Other

        public Param AllowUnsafeCode;

        public Param OpenAIAPIKeyConfigured;

        public Param GCPAPIKeyConfigured;

        #endregion
    }
}
