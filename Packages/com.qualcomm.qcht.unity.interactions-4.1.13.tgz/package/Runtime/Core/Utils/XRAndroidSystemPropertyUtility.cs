// /******************************************************************************
//  * File: XRAndroidSystemPropertyUtility.cs
//  * Copyright (c) 2022 Qualcomm Technologies, Inc. and/or its subsidiaries. All rights reserved.
//  *
//  * Confidential and Proprietary - Qualcomm Technologies, Inc.
//  *
//  ******************************************************************************/

using System.Runtime.InteropServices;

namespace QCHT.Interactions.Core
{
    public static class XRAndroidSystemPropertyUtility
    {
        private const string DllName = "QCHTOpenXRPlugin";
        
        [DllImport(DllName)]
        public static extern bool GetSystemPropertyEnabled(string propertyName);
    }
}